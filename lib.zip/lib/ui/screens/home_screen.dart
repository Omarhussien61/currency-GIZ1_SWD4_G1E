import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Import for local storage
import '../widgets/conversion_result_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> _targetCurrencies = [];
  double _inputAmount = 0.0;

  @override
  void initState() {
    super.initState();
    _loadSavedCurrencies();
  }

  Future<void> _loadSavedCurrencies() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? savedCurrencies = prefs.getStringList('targetCurrencies');
    if (savedCurrencies != null && savedCurrencies.isNotEmpty) {
      setState(() {
        _targetCurrencies = savedCurrencies; // Restore currencies
      });
    }
  }

  Future<void> _saveCurrenciesToLocal() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('targetCurrencies', _targetCurrencies);
  }

  void _addCurrency(String selectedCurrency) {
    setState(() {
      if (!_targetCurrencies.contains(selectedCurrency)) {
        _targetCurrencies.add(selectedCurrency);
        _saveCurrenciesToLocal();
      }
    });
  }

  void _removeCurrency(String currency) {
    setState(() {
      _targetCurrencies.remove(currency);
      _saveCurrenciesToLocal();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Currency Converter")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Currency input field
            CurrencyInputField(
              onChanged: (value) {
                setState(() {
                  _inputAmount = double.tryParse(value) ?? 0.0; 
                });
              },
            ),
            ElevatedButton(
              onPressed: () async {
                String? selectedCurrency = await showDialog(
                  context: context,
                  builder: (context) {
                    return SimpleDialog(
                      title: const Text("Select Currency"),
                      children: [
                        SimpleDialogOption(
                          onPressed: () {
                            Navigator.pop(context, "GBP");
                          },
                          child: const Text("GBP"),
                        ),
                        SimpleDialogOption(
                          onPressed: () {
                            Navigator.pop(context, "CAD");
                          },
                          child: const Text("CAD"),
                        ),
                        SimpleDialogOption(
                          onPressed: () {
                            Navigator.pop(context, "EUR");
                          },
                          child: const Text("EUR"),
                        ),
                        SimpleDialogOption(
                          onPressed: () {
                            Navigator.pop(context, "IDR");
                          },
                          child: const Text("IDR"),
                        ),
                      ],
                    );
                  },
                );
                if (selectedCurrency != null) {
                  _addCurrency(selectedCurrency);
                }
              },
              child: const Text("+ Add Converter"),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _targetCurrencies.length,
                itemBuilder: (context, index) {
                  String currency = _targetCurrencies[index];
                  double rate = 1.0; 
                  double convertedAmount = _inputAmount * rate;

                  return Dismissible(
                    key: Key(currency),
                    onDismissed: (direction) {
                      _removeCurrency(currency);
                    },
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    child: ConversionResultCard(
                      currency: currency,
                      rate: rate,
                      convertedAmount: convertedAmount,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}